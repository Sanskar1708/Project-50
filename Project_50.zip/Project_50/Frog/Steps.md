step 1)  Fold the paper in half diagonally.

step 2) Fold the paper in half again.

step 3) Open the top flap of paper over to the right.

step 4) Squash Fold this flap flat.

step 5) Turn the paper over.

step 6) Open the top flap of paper over to the left and Squash Fold it flat.

step 7) Open the flap of paper on the right over to the left and Squash Fold it flat.

step 8) Fold a couple of flaps over and then repeat step 7 on the 3 remaining flaps Squash Folding each flat.

step 9) Make a Petal Fold along the dotted lines. Fold in the sides first to give you creases to make the Petal Fold easier. 

step 10) Finish the Petal Fold and then repeat on the remaining 3 flaps of paper. This will give you a complete Frog Base.

step 11) Fold both sides of the paper to the center along the dotted lines.

step 12) Repeat step 11 on the remaining 3 sections.

step 13) Make an Inside Reverse Fold on each side along the dotted lines. This will bring the front two legs up.

step 14) Make two Inside Reverse Folds on the front legs bringing them out to the side. Then make two Inside Reverse Folds on the back legs also bringing them out to the side.

step 15) Make two more Inside Reverse Folds on the front legs and two more on the back legs.

step 16) Fold the top part of the paper underneath the frog. If you’re up to it you can try making an Open Sink here instead. It’ll look a little bit nicer when you’re done. Make two more Inside Reverse Folds on the back legs.