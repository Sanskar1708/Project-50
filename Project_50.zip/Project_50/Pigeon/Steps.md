**Step 1)** Fold the paper in half and then unfold it.

**Step 2)** Fold the paper in half the other way.

**Step 3)** Fold both layers of paper to the right along the dotted line.

**Step 4)** Fold the top layer of paper to the left along the dotted line.

**Step 5)** Fold the model in half down along the dotted line.

**Step 6)** Fold the top flap of paper up along the dotted line and then repeat on the other side.

**Step 7)** Fold the paper along the dotted line and then unfold it.

**Step 8)** Make an Inside Reverse Fold using the crease from the previous step.