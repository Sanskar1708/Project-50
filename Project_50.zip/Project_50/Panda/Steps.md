**Step 1)** Fold and unfold the paper in half both ways.

**Step 2)** Fold both sides in along the dotted lines.

**Step 3)** Fold and unfold the bottom and top along the dotted lines.

**Step 4)** Fold the paper behind along the dotted line.

**Step 5)** Turn the paper over.

**Step 6)** Fold the top of the paper down along the dotted line.

**Step 7)** Fold the paper up along the dotted line.

**Step 8)** Fold and unfold the paper in half and leave slightly folded to give a 3D look.